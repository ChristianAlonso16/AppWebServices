package server;

public class Methods {
    public double add ( double num1, double num2){
        return (num1+num2);
    }
}

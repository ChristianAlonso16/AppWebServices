package server;

public class IMC {
    public double imc (double peso, double altura) {
        return (peso / (altura * altura));
    }
    public String imc2 (String name,double peso, double altura){
        double imc = peso/(altura*altura);
        return "Nombre: " + name
                + " Tu imc es: " + imc;
    }
}

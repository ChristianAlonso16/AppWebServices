package client;

import org.apache.xmlrpc.XmlRpcException;
import org.apache.xmlrpc.client.XmlRpcClient;
import org.apache.xmlrpc.client.XmlRpcClientConfigImpl;

import java.net.MalformedURLException;
import java.net.URL;

public class RPCClient {
    public static void main(String[] args) throws MalformedURLException, XmlRpcException {
        XmlRpcClientConfigImpl config = new XmlRpcClientConfigImpl();
        config.setServerURL(new URL("http://localhost:1200")); //url donde esta corriendo
        //se configura el request
        XmlRpcClient client = new XmlRpcClient(); //se le añade la configuracion al cliente
        client.setConfig(config);
        Object[] numbers = {5.0,5D}; //Se crea un arreglo para traer los numeros, la D en el numero es para indicarle que es de tipo Double
        Double response = (Double) client.execute("Methods.add",numbers); //Se envian los numeros al metodo del servidor
        System.out.println("Result ="+ response);
    }
}
